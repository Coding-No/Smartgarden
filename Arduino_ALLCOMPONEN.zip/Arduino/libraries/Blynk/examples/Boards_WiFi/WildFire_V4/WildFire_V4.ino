/*************************************************************
  Blynk is a platform with iOS and Android apps to control
  ESP32, Arduino, Raspberry Pi and the likes over the Internet.
  You can easily build mobile and web interfaces for any
  projects by simply dragging and dropping widgets.

    Downloads, docs, tutorials: https://www.blynk.io
    Sketch generator:           https://examples.blynk.cc
    Blynk community:            https://community.blynk.cc
    Follow us:                  https://www.fb.com/blynkapp
                                https://twitter.com/blynk_app

  Blynk library is licensed under MIT license
  This example code is in public domain.

 *************************************************************
  This example shows how to use WildFire V4
  to connect your project to Blynk.

  NOTE: You need to install Arduino IDE WildFire support:
    http://shop.wickeddevice.com/resources/wildfire/

  Change WiFi ssid, pass, and Blynk auth token to run :)
  Feel free to apply it to any other example. It's simple!
 *************************************************************/

/* Comment this out to disable prints and save space */
#define BLYNK_PRINT Serial

/* Fill in information from Blynk Device Info here */
//#define BLYNK_TEMPLATE_ID           "TMPxxxxxx"
//#define BLYNK_TEMPLATE_NAME         "Device"
//#define #define BLYNK_AUTH_TOKEN "MASUKIN_TOKEN_BLYNK_LO"


#include <ESP8266_Lib.h>
#include <BlynkSimpleShieldEsp8266.h>

// Your WiFi credentials.
// Set password to "" for open networks.
char ssid[] = "NAMA_WIFI_LO";
char pass[] = "PASSWORD_WIFI_LO";

// Digital the pin that is used to reset/enable the ESP8266 module
const int EspSwitch =  23;

ESP8266 wifi(&Serial1);

void setup()
{
  // Debug console
  Serial.begin(9600);
  delay(10);

  // Set ESP8266 baud rate
  Serial1.begin(115200);
  delay(10);

  // Reset ESP
  pinMode(EspSwitch, OUTPUT);
  digitalWrite(EspSwitch, LOW);
  delay(50);
  digitalWrite(EspSwitch, HIGH);

  // Configure Blynk connection
  Blynk.begin(BLYNK_AUTH_TOKEN, wifi, ssid, pass);
}

void loop()
{
  Blynk.run();
}

